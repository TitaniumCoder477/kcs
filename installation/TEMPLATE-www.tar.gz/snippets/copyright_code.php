<?php

print("

<!*
  * Kiosk Checkout System v2.0.0
  * Copyright © " . date("Y") . " by James Wilmoth. All rights reserved.
  * It is illegal to copy, reproduce, or modify this code in any form.
  * www.kioskcheckoutsystem.com
  *-->

");

?>