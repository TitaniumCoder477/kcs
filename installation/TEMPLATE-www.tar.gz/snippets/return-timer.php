<script>
	document.write("<a href='index.php' style='float:right' id='return-timer'>Back to home</a>");
</script>