<?php 
	print("<p id='footer'>Copyright &copy; " . date("Y") . " by James Wilmoth. All rights reserved.</p>");
?>
