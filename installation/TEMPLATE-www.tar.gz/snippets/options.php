<div class='panel panel-primary'>
	<div class='panel-heading'>
		<h3 class='panel-title'>Options</h3>
	</div>
	<div class='panel-body' id='options-content'>
		<a href='admin-auth.php'>
			<button type='button' class='btn btn-lg btn-default'>Admin</button>				
		</a>
	</div>
</div>