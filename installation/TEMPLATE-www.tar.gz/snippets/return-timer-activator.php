<script>
	window.onload = function () {
		var display = document.querySelector('#return-timer');
		redirectPageOnCountdown("Home in... ", 20, "", display, "../index.php");
	};
</script>