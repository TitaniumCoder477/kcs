<?php require("snippets/copyright.php"); ?>
<?php require("snippets/dump_cookies.php"); ?>